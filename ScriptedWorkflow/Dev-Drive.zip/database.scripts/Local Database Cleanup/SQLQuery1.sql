USE [master]
GO
ALTER DATABASE [TSMSelenium] SET  online

ALTER DATABASE [SolutionsEnablementApplicationMap] SET  online
ALTER DATABASE [TSMSelenium] SET  online
ALTER DATABASE [Organization] SET  online
ALTER DATABASE [Patronage] SET  online
ALTER DATABASE [LightningProxy] SET  online
GO
