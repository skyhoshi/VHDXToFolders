. "D:\kernm.devcontainer.envsetup\Dev-Drive\By Project\AD-SE1\Setup-VSAndVSCodeSharedUserSettings.ps1"
. "D:\kernm.devcontainer.envsetup\Dev-Drive\By Project\AD-SE1\Setup-ODIE.ps1"

