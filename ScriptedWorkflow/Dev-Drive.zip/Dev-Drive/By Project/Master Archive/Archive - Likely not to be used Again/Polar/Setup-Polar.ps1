
. './../../Dev-Drive/Setup/setup-new-project.ps1'


[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/EnterpriseGIS/Polar";

New-DevelopmentStorageEnvironment -ProjectId 99999 -ProjectName "Polar-GIS" -ProjectRootDriveLetter 'N' -GitRepoUrl $repos 
#-GitRepoBranchName "experimental/dev-container"