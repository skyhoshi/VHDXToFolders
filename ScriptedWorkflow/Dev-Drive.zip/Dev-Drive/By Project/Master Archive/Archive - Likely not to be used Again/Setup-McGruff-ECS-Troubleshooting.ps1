. ".\..\..\Dev-Drive\Setup\setup-new-project.ps1"

[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/McGruff/McGruff","git@ssh.dev.azure.com:v3/fcsamerica/SolutionsEnablement/EnterpriseConfigurationStore";

New-DevelopmentStorageEnvironment -ProjectId 155815 -ProjectName "McGruffECSTroubleshooting" -ProjectRootDriveLetter 'N' -GitRepoUrl $repos #-GitRepoBranchName "experimental/dev-container"
