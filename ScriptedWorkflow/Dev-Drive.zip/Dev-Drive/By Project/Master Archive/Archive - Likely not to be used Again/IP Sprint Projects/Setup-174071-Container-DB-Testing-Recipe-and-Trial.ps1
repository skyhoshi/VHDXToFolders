# 
$previousLocation = $PWD;
Mount-CurrentProject;
Set-Location $PSScriptRoot
. ".\..\..\Dev-Drive\Setup\setup-new-project.ps1"

[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/Sandbox/TestContainers.174071-Container-DB-Testing-Recipe-and-Trial";

New-DevelopmentStorageEnvironment -ProjectId 174071 -ProjectName "TestContainers" -ProjectRootDriveLetter 'I' -GitRepoUrl $repos 