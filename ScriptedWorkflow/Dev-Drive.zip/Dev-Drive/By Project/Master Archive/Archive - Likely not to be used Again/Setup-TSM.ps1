# 
#$previousLocation = $PWD

Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
[string[]]$repos = "fcsamerica@vs-ssh.visualstudio.com:v3/fcsamerica/QA/TSMSelenium"
$projectName = "TSM"
$projectId = 214331
$driveLetter = "M"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 

#Create-DotNetTemplatesForMigration -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter

# Create-DotNetTemplatesForMigration -API -ProjectId $projectId -ProjectName "$($projectName)" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -API -ProjectId $projectId -ProjectName "$($projectName)Admin" -ProjectRootDriveLetter $driveLetter
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -UI -ProjectId $projectId -ProjectName "$($projectName)External" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -UI -ProjectId $projectId -ProjectName "$($projectName)Internal" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
