# 
#$previousLocation = $PWD
Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/LoanMonitoring/LoanMonitoringWeb","git@ssh.dev.azure.com:v3/fcsamerica/LoanMonitoring/LoanMonitoringAPI","git@ssh.dev.azure.com:v3/fcsamerica/MyAccount/MyAccount.Hub"

$projectName = "LoanMonitoring"

$projectId = 193548
$projectId = 207331
$driveLetter = "L"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos -SkipGitOperations $false

# Create-DotNetTemplatesForMigration -API -ProjectId $projectId -ProjectName "$($projectName)" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -API -ProjectId $projectId -ProjectName "$($projectName)Admin" -ProjectRootDriveLetter $driveLetter
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -UI -ProjectId $projectId -ProjectName "$($projectName)External" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
# Create-DotNetTemplatesForMigration -UI -ProjectId $projectId -ProjectName "$($projectName)Internal" -ProjectRootDriveLetter $driveLetter 
# Write-host "-----------------------------"
