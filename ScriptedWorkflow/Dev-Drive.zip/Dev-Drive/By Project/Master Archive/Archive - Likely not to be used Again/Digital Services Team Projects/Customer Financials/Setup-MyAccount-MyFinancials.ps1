# 
#$previousLocation = $PWD

Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/MyAccount/MyAccount.MyFinancials","git@ssh.dev.azure.com:v3/fcsamerica/CustomerFins/CustomerFins","git@ssh.dev.azure.com:v3/fcsamerica/EnterpriseDecisionEngine/DecisionLoadTester"
$projectName = "MyAccountMyFinancials"
$projectId = 195019
$driveLetter = "N"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 
#Create-DotNetTemplatesForMigration -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter

# $Domain = "digital-experience"
# $AppId = "MAF"
# "digitial-experience/maf/myaccountfinance/api"
