# 
$previousLocation = $PWD
Mount-CurrentProject
Set-Location $PSScriptRoot
. ".\..\..\Dev-Drive\Setup\setup-new-project.ps1"

[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/CreditAndResolutionsTool/CreditAndResolutionsTool"

$projectName = "CreditAndResolutionsTool"

# $projectId = 171479
# $driveLetter = "G"
# New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter 'G' -GitRepoUrl $repos 

# #Second Ticket with the same repo but different work
# $projectId = 175793
# $driveLetter = "H"
# New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter 'H' -GitRepoUrl $repos 

# dotnet new update
# dotnet new fcsaaspnetwebui -n CreditAndResolutionsTool

$projectId = 17595
$driveLetter = "I"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 

if (!(Test-Path jobtemplatedefault)) {
    #
    mkdir jobtemplatedefault
    Set-Location jobtemplatedefault
    #
    dotnet new update
    dotnet new fcsajob -n $projectName
}
#
$driveLetter = "I"
Set-Location "$($driveLetter):\$($projectName)\src"
if (!(Test-Path .env)) {
    Copy-Item .env_template .env
}
Set-Location /
