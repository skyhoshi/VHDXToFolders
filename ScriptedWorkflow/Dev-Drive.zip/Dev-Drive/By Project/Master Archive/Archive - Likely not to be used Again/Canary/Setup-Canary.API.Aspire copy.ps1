# 
#$previousLocation = $PWD

Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/SolutionsEnablement/Canary.Web.API","git@ssh.dev.azure.com:v3/fcsamerica/Sandbox/Corwin-Aspire","git@ssh.dev.azure.com:v3/fcsamerica/SolutionsEnablement/Canary.Web.UI"
$projectName = "Canary.API-Aspire"
$projectId = 194604
$driveLetter = "N"
$branchName = "experiment\$($projectId)-AspireDB"
#Remove-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos -GitRepoBranchName $branchName
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos -GitRepoBranchName $branchName
#Create-DotNetTemplatesForMigration -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter


