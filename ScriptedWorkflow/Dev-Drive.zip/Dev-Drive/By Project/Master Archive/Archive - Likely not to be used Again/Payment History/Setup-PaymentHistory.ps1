. ".\..\..\Dev-Drive\Setup\setup-new-project.ps1"

[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/PaymentHistory/PaymentHistory";

New-DevelopmentStorageEnvironment -ProjectId 9999 -ProjectName "paymenthistoryassessment" -ProjectRootDriveLetter 'N' -GitRepoUrl $repos #-GitRepoBranchName "experimental/dev-container"