# 
$previousLocation = $PWD;
Mount-CurrentProject;
Set-Location $PSScriptRoot
. ".\..\..\..\..\Dev-Drive\Setup\setup-new-project.ps1"

[string[]]$repos = "git@ssh.dev.azure.com:v3/fcsamerica/EnterpriseDecisionEngine/DecisionLoadTester";

New-DevelopmentStorageEnvironment -ProjectId 171479 -ProjectName "DecisionLoadTester" -ProjectRootDriveLetter 'H' -GitRepoUrl $repos -GitRepoBranchName "release/#175970_AddingFDM"

#
# FromBase64String
# Console.Write(Convert.ToBase64String(System.Text.Encoding.Default.GetBytes("0oa1p19z48dj54EWM0h8:lGlTKoApf1wd6ATlSJeDuqPgWO73xtXFRCfUuv-q")));
# Console.Write(System.Text.Encoding.Default.GetString(Convert.FromBase64String("dGVzdGluZ1ZhbHVlN0ExODMyaDUhNTp0ZXN0aW5nU2VjcmV0b0EzNExMSkZqZmpsaWUzMTI=")));

