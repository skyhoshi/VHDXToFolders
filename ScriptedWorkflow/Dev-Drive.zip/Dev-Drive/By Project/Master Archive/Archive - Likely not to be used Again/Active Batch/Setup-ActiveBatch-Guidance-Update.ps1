# 
$previousLocation = $PWD
Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1";
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1";

[string[]]$repos = ""

$repos = "git@ssh.dev.azure.com:v3/fcsamerica/Shared.Libraries/Solution.Templates"
$projectName = "ActiveBatchSharedTemplatesUpdate"

$projectId = 187419
$driveLetter = "N"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 

#Create-DotNetTemplatesForMigration -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter