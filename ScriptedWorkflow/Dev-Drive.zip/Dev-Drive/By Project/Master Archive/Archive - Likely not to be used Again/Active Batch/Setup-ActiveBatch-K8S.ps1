# 
$previousLocation = $PWD
Mount-CurrentProject
Set-Location $PSScriptRoot
$pathingBackToRepoRoot = ".\..\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
[string[]]$repos = ""

# $repos = "git@ssh.dev.azure.com:v3/fcsamerica/SolutionsEnablement/ActiveBatchK8sJobManager-POC"
# $projectName = "ActiveBatchPOC"

# $projectId = 187356
# $driveLetter = "J"
# New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 

# Create-DotNetTemplatesForMigration -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter


$repos = "git@ssh.dev.azure.com:v3/fcsamerica/Common/ATB.ActiveBatchSideKubernetesActiveBatchJobExecutor";
$projectName = "ActiveBatchSideKubeExecutor";
$projectId = 187356
$driveLetter = "E"
New-DevelopmentStorageEnvironment -ProjectId $projectId -ProjectName $projectName -ProjectRootDriveLetter $driveLetter -GitRepoUrl $repos 
