$pathingBackToRepoRoot = ".\..\..\..\";
$pathingBackToDevDriveSetupFolder = "$($pathingBackToRepoRoot)Dev-Drive\Setup";
. "$($pathingBackToDevDriveSetupFolder)\setup-new-project.ps1"
. "$($pathingBackToDevDriveSetupFolder)\setup-after-newproject.ps1"
$pathingBackToByProjectFolder = "$($pathingBackToRepoRoot)Dev-Drive\By Project";
. "$($pathingBackToByProjectFolder)\Setup-ActiveBatch-K8S.ps1"
. "$($pathingBackToByProjectFolder)\Setup-Canary-ActiveBatch.ps1"


